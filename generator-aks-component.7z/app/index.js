'use strict';
const Generator = require('yeoman-generator');
module.exports = class extends Generator {
  constructor(args, opts) {
    super(args, opts);
    this.log('Initializing...');
	 this.argument('appname', { type: String, required: false });
  }
  
  /*start() {
    this.log('Do something...');
	this.prompt([
    {
      type    : 'input',
      name    : 'name',
      message : 'Enter a name for the new component (i.e.: myNewComponent): '
    }
  ]).then( (answers) => {
    // create destination folder
    this.destinationRoot(answers.name);
  });
  
  }
  */
    // Async Await
  async prompting() {
    this.answers = await this.prompt([{
      type: 'input',
      name: 'name',
      message: 'Enter a name for the new component',
      default: this.appname, // appname return the default folder name to project
      store: true,
    }]);
  }

    writing() {
		this.fs.copyTpl(
		  this.templatePath('index.html'),
		  this.destinationPath(this.answers.name + '.html'), {title:this.answers.name}
		);
		this.fs.copyTpl(
		  this.templatePath('DevOpsMetadata.json'),
		  this.destinationPath('DevOpsMetadata.json'), {title:this.answers.name}
		);
		this.fs.copyTpl(
		  this.templatePath('Dockerfile'),
		  this.destinationPath('Dockerfile'), {title:this.answers.name}
		);
		this.fs.copyTpl(
		  this.templatePath('Jenkinsfile'),
		  this.destinationPath('Jenkinsfile'), {title:this.answers.name}
		);
		this.fs.copyTpl(
		  this.templatePath('README.md'),
		  this.destinationPath('README.md'), {title:this.answers.name}
		);
		
		
		this.fs.copyTpl(
		  this.templatePath('config/deploy-config/templates/deployment.yaml'),
		  this.destinationPath('config/deploy-config/templates/deployment.yaml')
		);
		this.fs.copyTpl(
		  this.templatePath('config/deploy-config/templates/ingress.yaml'),
		  this.destinationPath('config/deploy-config/templates/ingress.yaml')
		);
		this.fs.copyTpl(
		  this.templatePath('config/deploy-config/templates/service.yaml'),
		  this.destinationPath('config/deploy-config/templates/service.yaml')
		);
		
		
		
		this.fs.copyTpl(
		  this.templatePath('config/deploy-config/Chart.yaml'),
		  this.destinationPath('config/deploy-config/Chart.yaml')
		);
		this.fs.copyTpl(
		  this.templatePath('config/deploy-config/values.dev.yaml'),
		  this.destinationPath('config/deploy-config/values.dev.yaml'), {title:this.answers.name}
		);
		this.fs.copyTpl(
		  this.templatePath('config/deploy-config/values.qa.yaml'),
		  this.destinationPath('config/deploy-config/values.qa.yaml')
		);
		this.fs.copyTpl(
		  this.templatePath('config/deploy-config/values.prod.yaml'),
		  this.destinationPath('config/deploy-config/values.prod.yaml')
		);
		
		
		
		this.fs.copyTpl(
		  this.templatePath('config/config-map/app.config.prod.json'),
		  this.destinationPath('config/config-map/app.config.prod.json')
		);
		this.fs.copyTpl(
		  this.templatePath('config/config-map/app.config.qa.json'),
		  this.destinationPath('config/config-map/app.config.qa.json')
		);
		this.fs.copyTpl(
		  this.templatePath('config/config-map/application.dev.properties'),
		  this.destinationPath('config/config-map/application.dev.properties'), {title:this.answers.name}
		);
		this.fs.copyTpl(
		  this.templatePath('config/config-map/application.prod.properties'),
		  this.destinationPath('config/config-map/application.prod.properties')
		);
		this.fs.copyTpl(
		  this.templatePath('config/config-map/nginx.dev.conf'),
		  this.destinationPath('config/config-map/nginx.dev.conf')
		);
		this.fs.copyTpl(
		  this.templatePath('config/config-map/nginx.prod.conf'),
		  this.destinationPath('config/config-map/nginx.prod.conf')
		);
		this.fs.copyTpl(
		  this.templatePath('config/config-map/nginx.qa.conf'),
		  this.destinationPath('config/config-map/nginx.qa.conf')
		);


		this.fs.copyTpl(
			this.templatePath('oci-child/pom.xml'),
			this.destinationPath(this.answers.name+'-oci-child/pom.xml')
		);
		
		this.fs.copyTpl(
			this.templatePath('oci-parent/pom.xml'),
			this.destinationPath(this.answers.name+'-oci-parent/pom.xml')
		);
	}


};
//https://medium.com/@vallejos/yeoman-guide-adea4d6ea1e3